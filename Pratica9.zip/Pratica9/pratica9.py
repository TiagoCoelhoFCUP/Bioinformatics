from BinaryTree import BinaryTree
from NumMatrix import NumMatrix


class HierarchicalClustering:

    def __init__(self, matdists):
        self.matdists = matdists # sequence distance matrix
    
    def execute_clustering(self):
        '''
        returns a tree based on distance matrix
        '''
        # initialize the trees
        trees = []
        # traverse all seqs and create a tree for each sequence
        for i in range(self.matdists.num_rows()):
            # create a tree for each leaf
            # add to list of trees
            # ... MUDEI AQUI
            trees.append(BinaryTree(i))
            
        # make a copy of the distance matrix to change it
        tableDist = self.matdists.copy() #MUDEI AQUI
        # iterations
        for k in range(self.matdists.num_rows(), 1, -1):
            # indices in the matrix for the minimum distance
            mins = tableDist.min_dist_indexes() # ... MUDEI AQUI
            i,j = mins[0], mins[1]
            # create a new tree joining the clusters
            # this will be internal node; height will half of distance in the distance matrix
            # set left tree; set right tree
            n = BinaryTree(-1, tableDist.get_value(i,j)/2,trees[i],trees[j]) # AJUDA AQUI AQUI AQUI
            if k > 2:
                # remove trees being joined from the list 
                ti = trees.pop(i)
                tj = trees.pop(j)
                dists = []
                # calculate the distance for the new cluster
                for x in range(tableDist.num_rows()):          
                    if x != i and x != j:
                        si = len(ti.get_cluster()) #|si|
                        sj = len(tj.get_cluster()) #|sj|
                        # use the weighted average to calculate the distances between the clusters
                        d = (si*tableDist.get_value(i,x) + sj * tableDist.get_value(j,x)) / (si+sj) #ALTEREI AQUI
                        dists.append(d)
                # update the matrix:
                # remove col corresponding to i and j
                # remove row corresponding to i and j
                # add row with new distances: dists
                # add col with zero distances: of len (|dists| + 1)
                # ...
                
                tableDist.remove_col(i)
                tableDist.remove_col(j)
                tableDist.remove_row(i)
                tableDist.remove_row(j)
                
                tableDist.add_row(dists)
                tableDist.add_col([0] * (len(dists)+1))
                
                trees.append(n)
            else: return n


def test():
    m = NumMatrix(5,5)
    m.set_value(0, 1, 2)
    m.set_value(0, 2, 5)
    m.set_value(0, 3, 7)
    m.set_value(0, 4, 9)
    m.set_value(1, 2, 4)
    m.set_value(1, 3, 6)
    m.set_value(1, 4, 7)
    m.set_value(2, 3, 4)
    m.set_value(2, 4, 6)
    m.set_value(3, 4, 3)
    hc = HierarchicalClustering(m)
    arv = hc.execute_clustering()
    arv.print_tree()
    
if __name__ == '__main__': 
    test()


from NumMatrix import NumMatrix
from HierarchicalClustering import HierarchicalClustering
from MySeq import MySeq
from PairwiseAlignment import PairwiseAlignment
from SubstMatrix import SubstMatrix

class UPGMA:

    def __init__(self, seqs, alseq):
        self.seqs = seqs        # list of seqs of class MySeq
        self.alseq = alseq      # parameters for pairwise align.
        self.create_mat_dist()  # run this method on the construtor distance matrix
        
    def create_mat_dist(self):
        # create distance matrix with dim N x N sequences
        self.matdist = NumMatrix(len(self.seqs), len(self.seqs))
        for i in range(len(self.seqs)):
            for j in range(i, len(self.seqs)):
                # retrieve the two sequences to align
                s1 = self.seqs[i] #mudei aqui
                s2 = self.seqs[j]  #mudei aqui
                # align the sequences
                self.alseq.needleman_Wunsch(s1, s2)
                # recover the alignment
                alin = self.alseq.recover_align() #mudei aqui
                ncd = 0
                # fill the matrix
                # distance defined as: number of different symbols in the alignment 
                for k in range(len(alin)):
                    col = alin.column(k)
                    if (col[0] != col[1]): ncd += 1
                # set distance value in the matrix; 
                self.matdist.set_value(i, j, ncd) #mudei aqui # invoke here the method to update matdist ncd
                    
    def run(self):
        # create an object of the class HierarchicalClustering
        ch = HierarchicalClustering(self.matdist) #mudei aqui
        # execute the clustering algorithm
        t = ch.execute_clustering() #mudei aqui
        return t

def test():
    seq1 = MySeq("ATAGCGAT")    
    seq2 = MySeq("ATAGGCCT")    
    seq3 = MySeq("CTAGGCCC")
    seq4 = MySeq("CTAGGCCT")    
    sm = SubstMatrix()    
    sm.create_submat(1, -1, "ACGT")    
    alseq = PairwiseAlignment(sm, -2)    
    up  = UPGMA([seq1, seq2, seq3, seq4], alseq)    
    arv = up.run()    
    arv.print_tree() 

    
if __name__ == '__main__': 
    test()

class BinaryTree:
    
    def __init__(self, val, dist = 0, left = None, right = None):
        self.value = val
        self.distance = dist
        self.left = left
        self.right = right

        
    def get_cluster(self):
        # returns a list of all leaves for that tree
        # fill the code ....
        lista = []
        self.get_cluster_rec(0, lista)
        return lista

    def get_cluster_rec(self, level, lista):

        if self.value >= 0:
            lista.append(self.value)
        else:
            if (self.left != None): 
                self.left.get_cluster_rec(level+1, lista) 
            if (self.right != None): 
                self.right.get_cluster_rec(level+1, lista) 
            
        return lista

    def print_tree(self):
        self.print_tree_rec(0, "Root")
    
    def print_tree_rec(self, level, side):
        tabs = ""
        for i in range(level): tabs += "\t"
        if self.value >= 0:
            print(tabs, side, " - value:", self.value)
        else:
            print(tabs, side, "- Dist.: ", self.distance)
            if (self.left != None): 
                self.left.print_tree_rec(level+1, "Left")
            if (self.right != None): 
                self.right.print_tree_rec(level+1, "Right")
     
    
    def size(self):
        ''' size of the tree: returns two values
        - number of internal nodes of the tree
        - number of leaves'''
        numleaves = 0
        numnodes = 0
        if self.value >= 0:
            numleaves = 1
        else: 
            if (self.left != None):
                resl = self.left.size()
            else: resl = (0,0)
            if (self.right != None):  
                resr = self.right.size() 
            else: resr = (0,0)
            numnodes += (resl[0] + resr[0] + 1)
            numleaves += (resl[1] + resr[1])
        return numnodes, numleaves

    def exists_leaf(self, leafnum):
        '''
        returns true or false if leafnum appears in the leaves of the tree
        '''
        l = self.get_cluster()
        for leaf in l:
            if leaf == leafnum: return True
        return False    

    def common_ancestor(self, leaf1, leaf2):
        ''' Return simplest tree that contains leaf1, leaf2
        '''
        if self.value >= 0: return None
        if self.left.exists_leaf(leaf1):
            if self.left.exists_leaf(leaf2):
                return self.left.common_ancestor(leaf1, leaf2)
            if self.right.exists_leaf(leaf2):
                return self
            return None
        if self.right.exists_leaf(leaf1):
            if self.right.exists_leaf(leaf2):
                return self.right.common_ancestor(leaf1, leaf2)
            if self.left.exists_leaf(leaf2):
                return self
            return None

    def distance_leaves(self, leafnum1, leafnum2):
        ''' distance between leafnum1 and leafnum2 using the common ancestor function.
        d(leaf1, leaf2) = 2 * height(common_ancest(leaf1, leaf2))
        '''
        ancestor = self.common_ancestor(leafnum1, leafnum2)
        return 2 * ancestor.distance

def test():
    # leaf
    a = BinaryTree(1)
    b = BinaryTree(2)
    c = BinaryTree(3)
    d = BinaryTree(4)
    # internal nodes
    e = BinaryTree(-1, 2.0, b, c)
    f = BinaryTree(-1, 1.5, d, a)
    g = BinaryTree(-1, 4.5, e, f)
    g.print_tree()
    print(g.get_cluster())


    # testing exercise 3
    print(g.size())
    print(g.exists_leaf(1))
    print(g.exists_leaf(5))
    g.common_ancestor(1,4).print_tree()
    print(g.distance_leaves(1,4))
    print(g.distance_leaves(1,2))

if __name__ == '__main__':
    test()


""" 

RESULTS

TASK 1
3)
[0.0, 0.0, 0.0, 0.0]
[3, 0.0, 0.0, 0.0]
[4, 6, 0.0, 0.0]
[5, 8, 9, 0.0]



TASK 2
1) [2, 3, 4, 1]
2) True, False
3) 3.0 9.0


TASK 3
1)
 Root - Dist.:  3.25
         Left - Dist.:  2.25
                 Left - Dist.:  1.0
                         Left  - value: 1
                         Right  - value: 0
                 Right  - value: 2
         Right - Dist.:  1.5
                 Left  - value: 4
                 Right  - value: 3

2)
Root - Dist.:  2.0
         Left - Dist.:  0.75
                 Left - Dist.:  0.5
                         Left  - value: 3
                         Right  - value: 1
                 Right  - value: 2
         Right  - value: 0
         
"""
